import React from 'react';
import TreeMap from "react-d3-treemap";
import "react-d3-treemap/dist/react.d3.treemap.css";
import { dataCountries, dataProvince, dataoldcountry } from "./countries";
import { datajose } from "./data";

console.log(dataCountries);
export default function Treemap() {
  return (
    <div className="Treemap">
      <TreeMap
        height={800}
        width={1600}
        data={datajose}
        valueUnit={"People"}
      />
    </div>
  );
}